﻿using UnityEngine;

public class EndButton : MonoBehaviour
{
    public void exit()
    {
        //Application.quit();
        Debug.Log("exit");
    }
}
