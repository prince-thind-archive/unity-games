﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class StartButton : MonoBehaviour
{
    public void GameStart()
    {
        SceneManager.LoadScene("Level1");
    }
}
